<?php

declare(strict_types=1);

namespace GoldClient\Api;

/**
 * Screenshot Uploader Service
 *
 * Handles screenshot uploads from the GoldClient.
 */
class ScreenshotUploader
{
    /** @var string Token key for HMAC validation. */
    private const TOKEN_KEY = "YOUR_SECRET_TOKEN_HERE";

    /** @var string Directory where screenshots will be stored. */
    private const UPLOAD_DIR = __DIR__;

    /** @var string Path to the debug log file. */
    private const LOG_FILE = __DIR__ . DIRECTORY_SEPARATOR . 'uploader.log';

    /**
     * Verbosity levels:
     * 0 - Disabled
     * 1 - Errors only (Auth failures, system errors)
     * 2 - Full Debug (Detailed request info, hash comparisons)
     */
    private const DEBUG_LEVEL = 0;

    /** @var array Map of format IDs to file extensions. */
    private const ALLOWED_FORMATS = [
        1 => 'bmp',
        2 => 'jpg',
        3 => 'png'
    ];

    /**
     * Entry point for the request handling.
     */
    public function handleRequest(): void
    {
        $this->log("New request received from " . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'), 2);

        try {
            $this->validateRequest();
            $this->authorize();

            $targetPath = $this->preparePath();
            $this->saveFile($targetPath);

            $this->log("Successfully uploaded: " . basename($targetPath), 2);

            http_response_code(204);

        } catch (\InvalidArgumentException $e) {
            $this->terminate(400, "Validation Error: " . $e->getMessage());
        } catch (\RuntimeException $e) {
            $this->terminate(403, "Authorization Error: " . $e->getMessage());
        } catch (\Exception $e) {
            $this->terminate(500, "System Error: " . $e->getMessage());
        }
    }

    /**
     * Validates that all required POST fields and FILES are present.
     */
    private function validateRequest(): void
    {
        $requiredFields = ['name', 'time', 'fmt', 'hash'];
        foreach ($requiredFields as $field) {
            if (empty($_POST[$field])) {
                throw new \InvalidArgumentException("Missing required POST field: $field");
            }
        }

        if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
            $errCode = $_FILES['file']['error'] ?? 'NO_FILE';
            throw new \InvalidArgumentException("File upload failed with error code: $errCode");
        }

        if (!isset(self::ALLOWED_FORMATS[(int)$_POST['fmt']])) {
            throw new \InvalidArgumentException("Unsupported format ID: " . $_POST['fmt']);
        }

        $this->log("Validation passed for incoming screenshot: " . $_FILES['file']['name'], 2);
    }

    /**
     * Verifies the authenticity of the request using HMAC-SHA256.
     */
    private function authorize(): void
    {
        $name = (string)$_POST['name'];
        $time = (string)$_POST['time'];
        $receivedHash = (string)$_POST['hash'];

        $payload = $name . $time;
        $fullHash = hash_hmac('sha256', $payload, self::TOKEN_KEY);
        $expectedHash = substr($fullHash, 0, 16);

        if (self::DEBUG_LEVEL >= 2) {
            $this->log("Auth Debug - Payload: [$payload] Expected: [$expectedHash] Received: [$receivedHash]", 2);
        }

        if (!hash_equals($expectedHash, $receivedHash)) {
            $this->log("Auth Failed for $name. IP: " . $_SERVER['REMOTE_ADDR'], 1);
            throw new \RuntimeException("Hash mismatch");
        }
    }

    /**
     * Sanitizes the path and ensures the target directory exists.
     */
    private function preparePath(): string
    {
        // Sanitize name
        $safeRelativePath = preg_replace('/[^a-zA-Z0-9_\-\/]/', '_', (string)$_POST['name']);
        $extension = self::ALLOWED_FORMATS[(int)$_POST['fmt']];

        $fullPath = self::UPLOAD_DIR . DIRECTORY_SEPARATOR . $safeRelativePath . '.' . $extension;

        // Prevent overwriting existing files
        if (file_exists($fullPath)) {
            throw new \RuntimeException("Conflict: File already exists at $safeRelativePath");
        }

        // Create nested directories if needed
        $directory = dirname($fullPath);
        if (!is_dir($directory)) {
            if (!mkdir($directory, 0755, true) && !is_dir($directory)) {
                throw new \Exception("Failed to create storage directory: $directory");
            }
            $this->log("Created new directory: $directory", 2);
        }

        return $fullPath;
    }

    /**
     * Moves the temporary uploaded file to the final destination.
     */
    private function saveFile(string $targetPath): void
    {
        if (!move_uploaded_file($_FILES['file']['tmp_name'], $targetPath)) {
            throw new \Exception("FileSystem error: Could not move temp file to $targetPath");
        }
    }

    /**
     * Internal logging utility.
     */
    private function log(string $message, int $level): void
    {
        if (self::DEBUG_LEVEL < $level) {
            return;
        }

        $levelStr = ($level === 1) ? 'ERROR' : 'DEBUG';
        $timestamp = date('Y-m-d H:i:s');
        $entry = "[$timestamp] [$levelStr] $message" . PHP_EOL;

        // Note: Ensure the web server has write permissions for this file
        file_put_contents(self::LOG_FILE, $entry, FILE_APPEND);
    }

    /**
     * Terminates the script with an HTTP error code.
     */
    private function terminate(int $code, string $message): void
    {
        $this->log("Terminating with code $code: $message", 1);
        http_response_code($code);
        exit($message);
    }
}

// Execute the service
(new ScreenshotUploader())->handleRequest();
