===========================================================================
   GOLDCLIENT API - SCREENSHOT UPLOADER INSTALLATION GUIDE
===========================================================================

[ ENGLISH ]

1. SYSTEM REQUIREMENTS
   - PHP 7.4 or higher (8.1+ recommended).
   - Standard PHP modules: hash, json, filter.
   - Write permissions for the directory where the script is located.

2. INSTALLATION
   - Upload 'upload.php' to your web server (e.g., http://your-site.com/upload.php).
   - Set permissions (chmod) for the script's directory to 755 (or 777) so it can create subfolders automatically.

3. CONFIGURATION (IMPORTANT)
   - Open 'upload.php' and find the constant: private const TOKEN_KEY = "...";
   - Enter your secret token.
   - This token MUST MATCH the value in your server's 'goldclient_api.ini' config:
     IMAGE_UPLOAD_TOKEN = "your_secret_token"
   - In the same 'goldclient_api.ini', set the full URL to the script:
     IMAGE_UPLOAD_URL = "http://your-site.com/upload.php"

4. DEBUGGING
   - If uploads are failing, check 'uploader.log' in the script directory.
   - Set 'DEBUG_LEVEL' to 1 or 2 inside the script for more details.


---------------------------------------------------------------------------

[ RUSSIAN ]

1. СИСТЕМНЫЕ ТРЕБОВАНИЯ
   - PHP 7.4 или выше (рекомендуется 8.1+).
   - Стандартные модули PHP: hash, json, filter.
   - Права на запись для директории, в которой расположен скрипт.

2. УСТАНОВКА
   - Загрузите файл 'upload.php' на ваш веб-сервер (например, http://your-site.com/upload.php).
   - Установите права (chmod) на папку, в которой лежит скрипт — 755 (или 777), чтобы он мог автоматически создавать подпапки для скриншотов.

3. НАСТРОЙКА (ВАЖНО)
   - Откройте 'upload.php' и найдите константу: private const TOKEN_KEY = "...";
   - Впишите туда ваш секретный токен.
   - Этот токен ДОЛЖЕН СОВПАДАТЬ со значением в конфиге 'goldclient_api.ini' на сервере:
     IMAGE_UPLOAD_TOKEN = "ваш_секретный_токен"
   - В этом же конфиге 'goldclient_api.ini' укажите полный путь к скрипту:
     IMAGE_UPLOAD_URL = "http://your-site.com/upload.php"

4. ОТЛАДКА
   - Если скриншоты не загружаются, проверьте файл 'uploader.log' в папке со скриптом.
   - Вы можете изменить 'DEBUG_LEVEL' на 1 или 2 внутри скрипта для получения подробных логов.

===========================================================================
