#include <amxmodx>
#include <amxmisc>
#include <gold_client_api>

#pragma ctrlchar	'\'
#pragma semicolon	1

new const VERSION[] = "2.0";
new const CONFIG_FILE[] = "goldclient_api.ini";

enum
{
	SECTION_NONE,
	SECTION_OPTIONS,
};

enum _:ConfigData
{
	Cfg_TicketLifetime,         // ticket lifetime in seconds
	Cfg_RejectTicket[256],
	Cfg_RejectOffline[256],
	Cfg_UploadQuality,
	gcl_screen_format:Cfg_UploadFormat,
	Cfg_UploadURL[512],
	Cfg_UploadToken[128],
};

new g_eConfig[ConfigData];

public plugin_init()
{
	register_plugin("GoldClient API", VERSION, "GoldStalker");

	register_dictionary("goldclient_api.txt");

	register_concmd("gcl_info", "cmd_client_info", ADMIN_BAN, "<name or #userid>");
	register_concmd("gcl_snap", "cmd_client_snap", ADMIN_BAN, "<name or #userid>");
	register_concmd("gcl_list", "cmd_client_list", ADMIN_BAN);

	// initial values
	g_eConfig[Cfg_TicketLifetime] = 60*60*24*3; // 3 days
	g_eConfig[Cfg_UploadQuality]  = 75;
	g_eConfig[Cfg_UploadFormat]   = SF_JPEG;

	ReadCfg();
}

public goldclient_authorize(id)
{
	if (g_eConfig[Cfg_RejectOffline][0])
	{
		if (!gcl_get_info(id, gci_synchronized))
		{
			RejectOffline(id);
			return PLUGIN_HANDLED;
		}
	}

	// check ticket lifetime
	if (g_eConfig[Cfg_TicketLifetime] > 0 && g_eConfig[Cfg_RejectTicket][0])
	{
		new ticketTime = gcl_get_info(id, gci_ticket_timestamp);
		new serverTime = get_systime();

		new diff = abs(serverTime - ticketTime);
		if (diff > g_eConfig[Cfg_TicketLifetime])
		{
			new szRejectCommand[128];
			copy(szRejectCommand, charsmax(szRejectCommand), g_eConfig[Cfg_RejectTicket]);
			PrepareCommonKeywordsForBuffer(id, szRejectCommand, charsmax(szRejectCommand));
			server_cmd("%s", szRejectCommand);
			return PLUGIN_HANDLED;
		}
	}

	return PLUGIN_CONTINUE;
}

public cmd_client_info(id, level, cid)
{
	if (!cmd_access(id, level, cid, 2))
		return PLUGIN_HANDLED;

	new arg[32];
	read_argv(1, arg, charsmax(arg));
	new player = cmd_target(id, arg, CMDTARGET_NO_BOTS);

	if (!player)
		return PLUGIN_HANDLED;

	if (!is_user_goldclient(player))
	{
		console_print(id, "  gcl_info: This target:(%i) isn't it goldclient player.", player);
		return PLUGIN_HANDLED;
	}

	// Print client info
	console_print(id, "\nClient info:");

	new szDate[64], szTag[64], szUIDHash[11];

	new lLastTimeUpdated = gcl_get_info(player, gci_lasttime_upd);
	if (lLastTimeUpdated > 0)
		format_time(szDate, charsmax(szDate), "%X %b %d %Y", lLastTimeUpdated);
	else
		formatex(szDate, charsmax(szDate), "None");

	gcl_get_info(player, gci_tag, szTag, charsmax(szTag));
	gcl_get_info(player, gci_unique_id, szUIDHash, charsmax(szUIDHash));

	console_print(id, "  Build:    %i (%X) (%s) - %s", gcl_get_info(player, gci_build), gcl_get_info(player, gci_hash), szDate, szTag);
	console_print(id, "  Steam:    %s", gcl_get_info(player, gci_steam)    ? "Yes" : "No");
	console_print(id, "  Beta:     %s", gcl_get_info(player, gci_beta)     ? "Yes" : "No");
	console_print(id, "  Windowed: %s", gcl_get_info(player, gci_windowed) ? "Yes" : "No");
	console_print(id, "  UID:      %s", szUIDHash);

	new wide, tall;
	gcl_get_info(player, gci_resolution, wide, tall);
	console_print(id, "  Screen:   %ix%i (Game)", wide, tall);

	// Print OS info
	console_print(id, "\nOS info:");
	console_print(id, "  Type:     %i", gcl_get_info(player, gci_os_type));

	new szOSName[32];
	gcl_get_info(player, gci_os_name, szOSName, charsmax(szOSName));
	console_print(id, "  Name:     %s", szOSName);
	console_print(id, "  Build:    %i", gcl_get_info(player, gci_os_build));
	console_print(id, "  Major:    %i", gcl_get_info(player, gci_os_major_version));
	console_print(id, "  Minor:    %i", gcl_get_info(player, gci_os_minor_version));

	return PLUGIN_HANDLED;
}

public cmd_client_snap(id, level, cid)
{
	if (!cmd_access(id, level, cid, 2))
		return PLUGIN_HANDLED;

	new arg[32];
	read_argv(1, arg, charsmax(arg));
	new player = cmd_target(id, arg, CMDTARGET_NO_BOTS);

	if (!player)
		return PLUGIN_HANDLED;

	if (!is_user_goldclient(player))
	{
		console_print(id, "  gcl_snap: This target:(%i) isn't it goldclient player.", player);
		return PLUGIN_HANDLED;
	}

	new szName[32];
	get_user_name(player, szName, charsmax(szName));

	new szMapName[32], szSteamID[21], szPathName[64];
	get_user_authid(player, szSteamID, charsmax(szSteamID));
	get_mapname(szMapName, charsmax(szMapName));
	formatex(szPathName, charsmax(szPathName), "screenshots/%s/%s-%i", szSteamID, szMapName, time());
	NormalizePathName(szPathName);

	if (gcl_take_snapshot(player, szPathName, g_eConfig[Cfg_UploadFormat], g_eConfig[Cfg_UploadQuality]))
	{
		console_print(id, "[GCL]: A successful snapshot for the player %s.", szName);
		console_print(id, "%s", GetFullPathURL(szPathName));
	}
	else
	{
		console_print(id, "[GCL]: Failed to snapshot for the player %s", szName);

		if (!g_eConfig[Cfg_UploadURL][0])
			console_print(id, "[GCL]: You have to specify IMAGE_UPLOAD_URL in config goldclient.ini");

		if (!g_eConfig[Cfg_UploadToken][0])
			console_print(id, "[GCL]: You have to specify IMAGE_UPLOAD_TOKEN in config goldclient.ini");
	}

	return PLUGIN_HANDLED;
}

public cmd_client_list(id, level, cid)
{
	if (!cmd_access(id, level, cid, 1))
		return PLUGIN_HANDLED;

	new szName[32], szIp[22], szTime[6];
	console_print(id, "\n\n------------------------------------------------------------------------------\n");
	console_print(id, "%-2s %-32s %-6s %-5s %-21s %s", "#", "Name", "Userid", "Time", "IP", "GoldClient");
	for (new i = 1; i <= get_maxplayers(); i++)
	{
		if (!is_user_connecting(i) && !is_user_connected(i))
			continue;

		get_user_name(i, szName, charsmax(szName));
		get_user_ip(i, szIp, charsmax(szIp));
		get_user_play_time(i, szTime, charsmax(szTime));

		console_print(id, "%-2i %-32s %-6i %-5s %-21s %s", i, szName, get_user_userid(i), szTime, szIp, is_user_goldclient(i) ? "yes" : "no");
	}

	console_print(id, "\n------------------------------------------------------------------------------\n\n");
	return PLUGIN_HANDLED;
}

new const G_SZ_LANG_KEYS[][] =
{
	"GCL_REASON_TIME_SYNC",
	"GCL_REASON_OFFLINE"
};

stock PrepareCommonKeywordsForBuffer(const id, szOutBuffer[], const outLen)
{
	new szName[32], szUserId[10], szSteam[33], szIp[17];

	formatex(szUserId, charsmax(szUserId), "#%d", gcl_get_info(id, gci_userid));

	gcl_get_info(id, gci_name, szName, charsmax(szName));
	gcl_get_info(id, gci_authid, szSteam, charsmax(szSteam));
	gcl_get_info(id, gci_ip, szIp, charsmax(szIp), true);

	replace_string(szOutBuffer, outLen, "[name]", szName);
	replace_string(szOutBuffer, outLen, "[userid]", szUserId);
	replace_string(szOutBuffer, outLen, "[steam]", szSteam);
	replace_string(szOutBuffer, outLen, "[ip]", szIp);

	for (new i = 0; i < sizeof(G_SZ_LANG_KEYS); i++)
	{
		new szTag[64];
		formatex(szTag, charsmax(szTag), "[lang:%s]", G_SZ_LANG_KEYS[i]);

		if (contain(szOutBuffer, szTag) != -1)
		{
			new szReason[256];
			formatex(szReason, charsmax(szReason), "%L", id, G_SZ_LANG_KEYS[i]);

			replace_string(szOutBuffer, outLen, szTag, szReason);
			break;
		}
	}
}

stock RejectOffline(const id)
{
	if (g_eConfig[Cfg_RejectOffline][0] == EOS)
		return;

	new szRejectCommand[128];
	copy(szRejectCommand, charsmax(szRejectCommand), g_eConfig[Cfg_RejectOffline]);
	PrepareCommonKeywordsForBuffer(id, szRejectCommand, charsmax(szRejectCommand));
	server_cmd("%s", szRejectCommand);
}

stock get_user_play_time(id, dest[], const length)
{
	new iMinutes = get_user_time(id) / 60;
	new iSeconds = get_user_time(id) % 60;

	new minutes[3], seconds[3], temp[2];
	num_to_str(iMinutes, temp, sizeof(temp));

	if (iMinutes >= 10)
	{
		minutes[0] = temp[0];
		minutes[1] = temp[1];
	}
	else
	{
		minutes[0] = '0';
		minutes[1] = temp[0];
	}

	minutes[2] = '\0';

	num_to_str(iSeconds, temp, sizeof(temp));
	if (iSeconds >= 10)
	{
		seconds[0] = temp[0];
		seconds[1] = temp[1];
	}
	else
	{
		seconds[0] = '0';
		seconds[1] = temp[0];
	}

	seconds[2] = '\0';

	formatex(dest, length, "%s:%s", minutes, seconds);
}

stock ReadCfg()
{
	new iSection, szKey[128], szValue[1024];
	new szFile[250], szConfigDir[64], szTemp[1024];

	get_localinfo("amxx_configsdir", szConfigDir, charsmax(szConfigDir));
	formatex(szFile, charsmax(szFile), "%s/%s", szConfigDir, CONFIG_FILE);

	new fHandle = fopen(szFile, "rt");

	while (!feof(fHandle))
	{
		fgets(fHandle, szTemp, charsmax(szTemp));
		trim(szTemp);

		if (szTemp[0] == '[')
		{
			GetCurrentSection(szTemp, iSection);
			continue;
		}

		if (!szTemp[0] || szTemp[0] == ';' || szTemp[0] == '/') continue;

		strtok(szTemp, szKey, charsmax(szKey), szValue, charsmax(szValue), '=');
		trim(szKey);
		trim(szValue);

		remove_quotes(szValue);

		switch (iSection)
		{
			case SECTION_OPTIONS:
			{
				if (equal(szKey, "REJECT_OFFLINE"))
					copy(g_eConfig[Cfg_RejectOffline], charsmax(g_eConfig[Cfg_RejectOffline]), szValue);

				else if (equal(szKey, "TICKET_LIFETIME"))
					g_eConfig[Cfg_TicketLifetime] = str_to_num(szValue);

				else if (equal(szKey, "REJECT_INVALID_TICKET_LIFETIME"))
					copy(g_eConfig[Cfg_RejectTicket], charsmax(g_eConfig[Cfg_RejectTicket]), szValue);

				else if (equal(szKey, "IMAGE_UPLOAD_URL"))
					copy(g_eConfig[Cfg_UploadURL], charsmax(g_eConfig[Cfg_UploadURL]), szValue);

				else if (equal(szKey, "IMAGE_UPLOAD_TOKEN"))
					copy(g_eConfig[Cfg_UploadToken], charsmax(g_eConfig[Cfg_UploadToken]), szValue);

				else if (equal(szKey, "IMAGE_UPLOAD_QUALITY"))
					g_eConfig[Cfg_UploadQuality] = str_to_num(szValue);

				else if (equal(szKey, "IMAGE_UPLOAD_FORMAT"))
				{
					if (equali(szValue, "PNG"))
						g_eConfig[Cfg_UploadFormat] = SF_PNG;
					else if (equali(szValue, "BMP"))
						g_eConfig[Cfg_UploadFormat] = SF_BMP;
					else
						g_eConfig[Cfg_UploadFormat] = SF_JPEG;
				}
			}
		}
	}

	fclose(fHandle);

	if (g_eConfig[Cfg_UploadURL][0] && g_eConfig[Cfg_UploadToken][0])
	{
		gcl_init_snapshot(g_eConfig[Cfg_UploadURL], g_eConfig[Cfg_UploadToken]);
	}
}

stock GetFullPathURL(const pathName[])
{
	new baseUrl[256];
	new len = strlen(g_eConfig[Cfg_UploadURL]);
	while (len >= 0 && g_eConfig[Cfg_UploadURL][len] != '/' && g_eConfig[Cfg_UploadURL][len] != '\\')
		len--;

	copy(baseUrl, min(len, charsmax(baseUrl)), g_eConfig[Cfg_UploadURL]);

	new imageExt[12];
	switch (g_eConfig[Cfg_UploadFormat])
	{
		case SF_JPEG: copy(imageExt, charsmax(imageExt), "jpg");
		case SF_PNG:  copy(imageExt, charsmax(imageExt), "png");
		case SF_BMP:  copy(imageExt, charsmax(imageExt), "bmp");
	}

	static fullPath[512];
	formatex(fullPath, charsmax(fullPath), "%s/%s.%s", baseUrl, pathName, imageExt);
	return fullPath;
}

stock GetCurrentSection(temp[1024], &section)
{
	if (contain(temp, "OPTIONS") != -1)
		section = SECTION_OPTIONS;
}

stock NormalizePathName(pathName[])
{
	new const invalid_chars[] = { '\\', ':', '*', '?', '"', '<', '>', '|' };
	for (new i; i < strlen(pathName); i++)
	{
		for (new c; c < sizeof(invalid_chars); c++)
		{
			if (pathName[i] == invalid_chars[c])
				pathName[i] = '_';
		}
	}
}
